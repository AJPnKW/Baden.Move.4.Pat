# Core renaming logic
